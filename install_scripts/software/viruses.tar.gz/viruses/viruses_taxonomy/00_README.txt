------------------------------
	accessions.txt
------------------------------
Plain text file with NCBI RefSeq assembly accession numbers for genomes contained in the index.

------------------------------
	genomes.accession2taxid
------------------------------
Plain text file providing a mapping between the accession.version from sequence records to NCBI taxonomy IDs.
The file has four columns separated by a TAB character:
accession<TAB>accession.version<TAB>taxid<TAB>gi

Columns:
1. Accession
   Accession of the sequence record, without a version. e.g. BA000005
2. Accession.version
   Accession of the sequence record together with the version number. 
   e.g. BA000005.3
   Some dead sequence records do not have any version number in which case the
   value in this column will be the accession followed by a dot. e.g. X53318.
3. TaxId
   Taxonomy identifier of the source organism for the sequence record. e.g. 9606
   If for some reason the source organism cannot be mapped to the taxonomy 
   database, the column will contain 0.
4. GI
   GI of the sequence record. e.g. 55417888
   NCBI is phasing out use of gi numbers, see:
   http://www.ncbi.nlm.nih.gov/news/03-02-2016-phase-out-of-GI-numbers/
   Some sequences such as unannotated WGS and TSA records already lack a GI.
   If a sequence record does not have a GI assigned, the column will contain na.

------------------------------
	names.dmp
------------------------------
Plain text file with taxonomy names from the NCBI taxonomy database. 
The file containing records on each line. Each record consists of 
fields delimited by "\t|\t" (tab, vertical bar, and tab) characters:

	tax_id					-- the id of node associated with this name
	name_txt				-- name itself
	unique name				-- the unique variant of this name if name not unique
	name class				-- (synonym, common name, ...)

------------------------------
	nodes.dmp
------------------------------
Plain text file describing taxonomy nodes from the NCBI taxonomy database. 
The file containing records on each line. Each record consists of 
fields delimited by "\t|\t" (tab, vertical bar, and tab) characters:

	tax_id					-- node id in GenBank taxonomy database
 	parent tax_id				-- parent node id in GenBank taxonomy database
 	rank					-- rank of this node (superkingdom, kingdom, ...) 
 	embl code				-- locus-name prefix; not unique
 	division id				-- see division.dmp file
 	inherited div flag  (1 or 0)		-- 1 if node inherits division from parent
 	genetic code id				-- see gencode.dmp file
 	inherited GC  flag  (1 or 0)		-- 1 if node inherits genetic code from parent
 	mitochondrial genetic code id		-- see gencode.dmp file
 	inherited MGC flag  (1 or 0)		-- 1 if node inherits mitochondrial gencode from parent
 	GenBank hidden flag (1 or 0)            -- 1 if name is suppressed in GenBank entry lineage
 	hidden subtree root flag (1 or 0)       -- 1 if this subtree has no sequence data yet
 	comments				-- free-text comments and citations

