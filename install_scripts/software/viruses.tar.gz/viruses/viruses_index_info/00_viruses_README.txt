------------------------------
	01 Index Summary
------------------------------
This files describes the summary of the index build process:
Motif used, Window size used, minimum length used, number of indexed 
sequences, number of skipped sequences, number of genomes in the index.

------------------------------
	02 Taxonomy Tree
------------------------------
Fields correspond to the NCBI Taxonomy database dump files fields with the
same name. For more information, read https://ftp.ncbi.nih.gov/pub/taxonomy/taxdump_readme.txt

parent_tax_id	-- parent node id in GenBank taxonomy database
tax_id		-- node id in GenBank taxonomy database
rank		-- rank of this node (superkingdom, kingdom, ...)
name_txt	-- name itself
unique_name	-- the unique variant of this name if name not unique
name_class	-- (synonym, common name, ...)

------------------------------
	03 Genome Index
------------------------------
Each row of this file contains represents a unique genome with a genome identifier and the genome's distance vector:
- 1. genome identifier:
tax_id followed by separator '\t|\t' followed by the genome name
- 2. '\t' separator- 3. distance vector:
Local distances separated by a single space ' '

------------------------------
	04 Permutation map
------------------------------
Each line contains the indexed sort space hash, followed by '->' and 
every genome index id that maps to that hash, separated by a single space.

------------------------------
	05 Overlap matrix
------------------------------
Square matrix where row and column indices correspond to the genome index id. 
In other words, the value at row 1, column 2, shows the overlap from genome with 
genome index id 2 for the genome with genome index 1.